## Walkable 3D port town: quay, anchored ship, colonial streets, tavern /
## store / shipyard / governor's mansion, lamp posts, a well, a market stall.
## Walk with WASD, orbit the camera with RMB, press E near a door to enter.
## Everything is procedural — no imported assets.
extends Node3D

const World := preload("res://core/world.gd")
const Sailing := preload("res://core/sailing.gd")
const ShipVisualScript := preload("res://scripts/ship_visual.gd")
const Person := preload("res://scripts/person.gd")
const DayCycle := preload("res://scripts/day_cycle.gd")
const PBR := preload("res://scripts/pbr.gd")

const WALK_SPEED := 9.0
const SAIL_SPEED_SCALE := 2.6
const ANCHOR_POS := Vector3(22, -0.8, -48)
const ANCHOR_ROT_Y := 65.0

var player: Node3D
var camera: Camera3D
var cam_yaw := 180.0
var cam_pitch := 18.0
var cam_dist := 15.0
var _orbiting := false
var _time := 0.0
var _ship_node: Node3D

# {pos: Vector3, label: String, action: Callable}
var _interactables: Array = []
## Building footprints the player cannot walk through (XZ rects).
var _colliders: Array = []   # Rect2: position = min corner (x, z)

# Interiors: rooms are built far below the town; entering teleports there.
var _interior_count := 0
var _inside := false
var _room_bounds := Rect2()
var _room_floor_y := 0.0
var _return_pos := Vector3.ZERO

# Harbor sailing: the player boards the ship and steers it around the bay.
var _sailing := false
var _ship_heading := 0.0
var _ship_len := 25.0
var _hint: Label
var _rng := RandomNumberGenerator.new()

# Player limb pivots for the walk cycle.
var _limbs := {}
var _walk_phase := 0.0
var _moving := false

const TIMBER := Color("3a2d1c")
var _house_sizes := {}
const WALL_COLORS := [Color("efe6d2"), Color("e6d3a8"), Color("d9b8a0"), Color("c9dcd4"), Color("e0c6c0")]
const ROOF_COLORS := [Color("9a4a2e"), Color("7d3b26"), Color("5d4024")]

## Every island has its own face: light, weather, ground palette and the
## shape of its town. Layouts: rows, plaza, terraces, hillside, boulevard,
## canal, scatter.
const ISLAND_LOOKS := {
	"oxbay": {"sun_color": "fff2d8", "sun_energy": 1.45, "sky_top": "2f6698",
		"horizon": "e8d8b8", "fog": 0.0012, "fog_color": "dcc9a6", "overcast": 0.0,
		"rain": false, "grass": "55713a", "sand": "c2a878", "hill": "42592f",
		"layout": "rows"},
	"redmond": {"sun_color": "ffe9c0", "sun_energy": 1.5, "sky_top": "2a5e94",
		"horizon": "f2e2c0", "fog": 0.0009, "fog_color": "e8d8b0", "overcast": 0.0,
		"rain": false, "grass": "5d7440", "sand": "cbb184", "hill": "4a6034",
		"layout": "plaza"},
	"isla_muelle": {"sun_color": "ffe2a8", "sun_energy": 1.6, "sky_top": "3a6a9a",
		"horizon": "f4dfae", "fog": 0.0006, "fog_color": "e8d3a0", "overcast": 0.0,
		"rain": false, "grass": "8a8148", "sand": "dcc48e", "hill": "7a6f3e",
		"layout": "terraces"},
	"conceicao": {"sun_color": "f4e6c8", "sun_energy": 1.25, "sky_top": "355e7a",
		"horizon": "cfd8c8", "fog": 0.0022, "fog_color": "c2cec0", "overcast": 0.35,
		"rain": true, "grass": "3d5c33", "sand": "b6a077", "hill": "2f4a28",
		"layout": "hillside"},
	"falaise_de_fleur": {"sun_color": "ffe6d4", "sun_energy": 1.4, "sky_top": "4a6ea0",
		"horizon": "f4d8cc", "fog": 0.0010, "fog_color": "ecd4c4", "overcast": 0.0,
		"rain": false, "grass": "5a7a44", "sand": "d2b990", "hill": "4d6a3a",
		"layout": "boulevard"},
	"douwesen": {"sun_color": "e8e4d8", "sun_energy": 1.1, "sky_top": "51616e",
		"horizon": "aeb6ae", "fog": 0.0020, "fog_color": "b8bcb4", "overcast": 0.7,
		"rain": true, "grass": "4c6240", "sand": "b0a480", "hill": "435538",
		"layout": "canal"},
	"quebradas": {"sun_color": "ffd9a0", "sun_energy": 1.3, "sky_top": "3c5a78",
		"horizon": "e8c090", "fog": 0.0016, "fog_color": "d8b890", "overcast": 0.15,
		"rain": false, "grass": "6a6438", "sand": "c9ad74", "hill": "5a5530",
		"layout": "scatter"},
}

var _look: Dictionary = {}
var _sun: DirectionalLight3D
var _env_res: Environment


func _ready() -> void:
	Music.play_ambience()
	_rng.seed = hash(Game.state.current_island)
	_look = ISLAND_LOOKS.get(Game.state.current_island, ISLAND_LOOKS["oxbay"])
	_build_environment()
	_build_terrain()
	_build_quay_and_ship()
	_build_town()
	_build_props()
	_build_player()
	_build_npcs()
	_build_hud()


func _island() -> Dictionary:
	return World.island(Game.state.current_island)


# --- Environment & terrain ---

func _build_environment() -> void:
	_sun = DirectionalLight3D.new()
	_sun.shadow_enabled = true
	_sun.directional_shadow_max_distance = 250.0
	add_child(_sun)

	var fill := DirectionalLight3D.new()
	fill.rotation_degrees = Vector3(-55, -130, 0)
	fill.light_energy = 0.3
	fill.light_color = Color(0.7, 0.78, 0.95)
	add_child(fill)

	var env := WorldEnvironment.new()
	var e := Environment.new()
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(_look["sky_top"])
	sky_mat.sky_horizon_color = Color(_look["horizon"])
	sky_mat.sky_curve = 0.14
	sky_mat.ground_bottom_color = Color("2a3c28")
	sky_mat.ground_horizon_color = Color(_look["horizon"])
	sky_mat.sun_angle_max = 25.0
	sky.sky_material = sky_mat
	e.background_mode = Environment.BG_SKY
	e.sky = sky
	e.tonemap_mode = Environment.TONE_MAPPER_ACES
	e.tonemap_exposure = 1.05
	e.glow_enabled = true
	e.glow_intensity = 0.45
	e.adjustment_enabled = true
	e.adjustment_saturation = 1.12
	e.fog_enabled = true
	e.fog_light_color = Color(_look["fog_color"])
	e.fog_density = float(_look["fog"])
	env.environment = e
	add_child(env)
	_env_res = e
	DayCycle.upgrade(_env_res, _look)
	DayCycle.apply(_sun, _env_res, Game.time_of_day, _look)

	if bool(_look["rain"]):
		_build_rain()

	camera = Camera3D.new()
	camera.far = 3000.0
	camera.fov = 65.0
	add_child(camera)


## Streaks of rain over the town (rainy islands only).
func _build_rain() -> void:
	var rain := GPUParticles3D.new()
	rain.amount = 900
	rain.lifetime = 1.1
	rain.preprocess = 1.0
	rain.visibility_aabb = AABB(Vector3(-130, -5, -90), Vector3(260, 70, 240))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(120, 1, 110)
	pm.direction = Vector3(0.12, -1, 0)
	pm.initial_velocity_min = 38.0
	pm.initial_velocity_max = 46.0
	pm.gravity = Vector3(0, -22, 0)
	rain.process_material = pm
	var quad := QuadMesh.new()
	quad.size = Vector2(0.035, 0.7)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.75, 0.82, 0.9, 0.32)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	quad.material = m
	rain.draw_pass_1 = quad
	rain.position = Vector3(0, 42, 20)
	add_child(rain)


func _build_terrain() -> void:
	# Grass starts BEHIND the quay — the bay stays pure water.
	var ground := MeshInstance3D.new()
	var gm := PlaneMesh.new()
	gm.size = Vector2(500, 360)
	ground.mesh = gm
	ground.position = Vector3(0, 0, 186)
	ground.material_override = PBR.mat("grass_ground", 5.0, Color(_look["grass"]).lerp(Color.WHITE, 0.6))
	add_child(ground)

	# A sandy shoreline strip between the quay and the grass.
	var sand := MeshInstance3D.new()
	var sm := PlaneMesh.new()
	sm.size = Vector2(500, 10)
	sand.mesh = sm
	sand.position = Vector3(0, 0.02, 5)
	sand.material_override = PBR.mat("coast_sand_01", 3.0, Color(_look["sand"]).lerp(Color.WHITE, 0.5))
	add_child(sand)

	# Streets: each layout paves its own plan.
	for cobble in _street_rects():
		var street := MeshInstance3D.new()
		var stm := PlaneMesh.new()
		stm.size = cobble["size"]
		street.mesh = stm
		street.position = cobble["pos"]
		street.material_override = PBR.mat("cobblestone_floor_05", 2.5)
		add_child(street)

	# Bay water with the same animated shader as at sea.
	var water := MeshInstance3D.new()
	var wm := PlaneMesh.new()
	wm.size = Vector2(1200, 810)
	wm.subdivide_width = 60
	wm.subdivide_depth = 40
	water.mesh = wm
	# Ends just past the quay so wave crests never poke through the land.
	water.position = Vector3(0, -0.8, -407)
	var wmat := ShaderMaterial.new()
	wmat.shader = load("res://assets/water.gdshader")
	var wnoise := FastNoiseLite.new()
	wnoise.frequency = 0.008
	wnoise.fractal_octaves = 4
	var wtex := NoiseTexture2D.new()
	wtex.noise = wnoise
	wtex.seamless = true
	wtex.width = 512
	wtex.height = 512
	wmat.set_shader_parameter("noise_tex", wtex)
	water.material_override = wmat
	add_child(water)

	# Hills as a backdrop.
	for i in 6:
		var hill := MeshInstance3D.new()
		var hm := SphereMesh.new()
		hm.radius = _rng.randf_range(60, 120)
		hm.height = _rng.randf_range(40, 80)
		hill.mesh = hm
		# Keep the near slope behind the town: no hill may reach past z = 90.
		var hill_z: float = _rng.randf_range(90.0 + hm.radius, 200.0 + hm.radius)
		hill.position = Vector3(_rng.randf_range(-220, 220), -8, hill_z)
		hill.material_override = PBR.mat("rocky_terrain_02", 18.0, Color(_look["hill"]).lerp(Color.WHITE, 0.6))
		add_child(hill)

	# The Dutch town gets its canal down the middle.
	if String(_look["layout"]) == "canal":
		var canal := MeshInstance3D.new()
		var cm := PlaneMesh.new()
		cm.size = Vector2(120, 9)
		canal.mesh = cm
		canal.position = Vector3(0, 0.05, 30)
		var cmat := StandardMaterial3D.new()
		cmat.albedo_color = Color("2c4a52")
		cmat.roughness = 0.15
		cmat.metallic = 0.3
		canal.material_override = cmat
		add_child(canal)
		for bx in [-20.0, 20.0]:
			var bridge := _mesh_box(Vector3(4.0, 0.5, 11.0), Vector3(bx, 0.55, 30), Color("8d8577"))
			bridge.rotation_degrees = Vector3(0, 0, 0)
		_colliders.append(Rect2(-60, 26.5, 40, 7))
		_colliders.append(Rect2(-16, 26.5, 32, 7))
		_colliders.append(Rect2(24, 26.5, 36, 7))

	# Palms.
	for i in 14:
		var x := _rng.randf_range(-90, 90)
		var z := _rng.randf_range(4, 90)
		if absf(x) < 40.0 and z < 66.0:
			continue  # keep the town clear
		_palm(Vector3(x, 0, z))


func _noise_tex(freq: float, dark: Color) -> NoiseTexture2D:
	var noise := FastNoiseLite.new()
	noise.frequency = freq
	var ramp := Gradient.new()
	ramp.set_color(0, dark)
	ramp.set_color(1, Color(1, 1, 1))
	var ntex := NoiseTexture2D.new()
	ntex.noise = noise
	ntex.color_ramp = ramp
	ntex.width = 256
	ntex.height = 256
	return ntex


## A coconut palm (Blender-built, Higgsfield fronds) at a random lean.
func _palm(pos: Vector3) -> void:
	var palm: Node3D = load("res://assets/props/palm_0%d.gltf" % _rng.randi_range(1, 3)).instantiate()
	palm.position = pos
	palm.rotation.y = _rng.randf() * TAU
	palm.scale = Vector3.ONE * _rng.randf_range(0.85, 1.2)
	add_child(palm)
	for mi: MeshInstance3D in palm.find_children("*", "MeshInstance3D", true, false):
		var src := mi.mesh.surface_get_material(0) as BaseMaterial3D
		if src != null and mi.name.begins_with("Fronds"):
			var m: BaseMaterial3D = src.duplicate()
			m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
			m.alpha_scissor_threshold = 0.4
			m.cull_mode = BaseMaterial3D.CULL_DISABLED
			mi.material_override = m


## A Poly Haven prop model, placed on the ground and turned.
func _prop(id: String, pos: Vector3, yaw := 0.0, scale := 1.0) -> Node3D:
	var n: Node3D = load("res://assets/props/%s.gltf" % id).instantiate()
	n.position = pos
	n.rotation.y = yaw
	n.scale = Vector3.ONE * scale
	add_child(n)
	return n


func _mat(c: Color, emissive := false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.9
	if emissive:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = 1.8
	return m


func _mesh_box(size: Vector3, pos: Vector3, c: Color, emissive := false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = _mat(c, emissive)
	add_child(mi)
	return mi


func _mesh_cyl(r_top: float, r_bot: float, h: float, pos: Vector3, c: Color, emissive := false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r_top
	cm.bottom_radius = r_bot
	cm.height = h
	mi.mesh = cm
	mi.position = pos
	mi.material_override = _mat(c, emissive)
	add_child(mi)
	return mi


# --- Quay & ship ---

func _build_quay_and_ship() -> void:
	var quay := _mesh_box(Vector3(140, 3.0, 10), Vector3(0, -0.6, -5), Color("948a76"))
	quay.material_override = PBR.mat("seaworn_stone_tiles", 2.5)

	# Mooring posts along the edge.
	for i in 8:
		var post := _mesh_cyl(0.22, 0.25, 1.4, Vector3(-56 + i * 16, 1.4, -9.2), TIMBER)
		post.material_override = PBR.mat("dark_wooden_planks", 1.0)

	# Cargo on the quay: barrels and sea chests, in little stacks.
	for i in 12:
		var x := _rng.randf_range(-55, 55)
		var z := _rng.randf_range(-7, -3)
		if absf(x) < 4.0 or absf(x - 14.0) < 3.0:
			continue  # keep the departure and boarding spots clear
		if _rng.randf() < 0.55:
			for k in _rng.randi_range(1, 3):
				_prop("wine_barrel_01", Vector3(x + k * 0.8, 0.9, z + _rng.randf_range(-0.2, 0.2)), _rng.randf() * TAU, 1.2)
		else:
			_prop("wooden_crate_02", Vector3(x, 0.9, z), _rng.randf() * TAU, 1.5)
			if _rng.randf() < 0.5:
				_prop("wooden_crate_01", Vector3(x, 0.9 + 0.68, z), _rng.randf() * TAU, 1.5)
	# Harbour guns at both ends of the quay, trained on the bay.
	for cx in [-62.0, 62.0]:
		_prop("cannon_01", Vector3(cx, 0.9, -7.5), PI, 1.25)

	# The player's ship anchored in the bay.
	_ship_node = Node3D.new()
	_ship_node.set_script(ShipVisualScript)
	add_child(_ship_node)
	_ship_len = ShipVisualScript.class_length(Game.state.ship.type_id)
	_ship_node.build(_ship_len, Color(World.NATIONS[Game.state.character.nation]["color"]), true, Game.state.ship.type_id, Game.state.character.nation)
	_ship_node.position = ANCHOR_POS
	_ship_node.rotation_degrees = Vector3(0, ANCHOR_ROT_Y, 0)
	_ship_node.set_sail_amount(0.06)

	_interactables.append({
		"pos": Vector3(14, 1.0, -9),
		"label": "배에 승선",
		"action": func(): _board_ship(),
	})
	_interactables.append({
		"pos": Vector3(0, 1.0, -8),
		"label": "%s에서 출항 - 목적지 선택" % _island()["name"],
		"action": func(): Game.goto_map(),
	})


# --- Town ---

## Street plan per layout (paved rectangles).
func _street_rects() -> Array:
	match String(_look["layout"]):
		"plaza":
			return [
				{"size": Vector2(36, 34), "pos": Vector3(0, 0.04, 30)},
				{"size": Vector2(12, 26), "pos": Vector3(0, 0.04, 6)},
			]
		"terraces":
			return [
				{"size": Vector2(92, 8), "pos": Vector3(0, 0.04, 18)},
				{"size": Vector2(80, 8), "pos": Vector3(6, 0.04, 33)},
				{"size": Vector2(66, 8), "pos": Vector3(12, 0.04, 49)},
				{"size": Vector2(10, 46), "pos": Vector3(-22, 0.04, 32)},
			]
		"hillside":
			return [
				{"size": Vector2(12, 58), "pos": Vector3(0, 0.04, 32)},
				{"size": Vector2(78, 10), "pos": Vector3(0, 0.04, 22)},
				{"size": Vector2(54, 8), "pos": Vector3(0, 0.04, 44)},
			]
		"boulevard":
			return [
				{"size": Vector2(122, 14), "pos": Vector3(0, 0.04, 30)},
				{"size": Vector2(12, 54), "pos": Vector3(0, 0.04, 34)},
			]
		"canal":
			return [
				{"size": Vector2(112, 8), "pos": Vector3(0, 0.04, 21)},
				{"size": Vector2(112, 8), "pos": Vector3(0, 0.04, 39)},
				{"size": Vector2(8, 44), "pos": Vector3(-44, 0.04, 26)},
				{"size": Vector2(8, 44), "pos": Vector3(44, 0.04, 26)},
			]
		"scatter":
			return [
				{"size": Vector2(64, 44), "pos": Vector3(0, 0.05, 28)},
			]
		_:
			return [
				{"size": Vector2(14, 60), "pos": Vector3(0, 0.04, 32)},
				{"size": Vector2(70, 12), "pos": Vector3(0, 0.04, 14)},
			]


## True when a footprint does not clip anything already built.
func _area_free(pos: Vector3, size: Vector3) -> bool:
	var rect := Rect2(pos.x - size.x / 2.0 - 1.0, pos.z - size.z / 2.0 - 1.0, size.x + 2.0, size.z + 2.0)
	for c: Rect2 in _colliders:
		if rect.intersects(c):
			return false
	return true


func _build_town() -> void:
	var layout := String(_look["layout"])

	# Special buildings claim their spots first, per layout.
	const SPECIAL_SPOTS := {
		"rows": {"tavern": Vector3(-26, 0, 12), "store": Vector3(26, 0, 12), "yard": Vector3(52, 0, 2), "gov": Vector3(0, 0, 62)},
		"plaza": {"tavern": Vector3(-26, 0, 30), "store": Vector3(26, 0, 30), "yard": Vector3(-50, 0, 4), "gov": Vector3(0, 0, 56)},
		"terraces": {"tavern": Vector3(-40, 0, 11), "store": Vector3(32, 0, 11), "yard": Vector3(54, 0, 2), "gov": Vector3(22, 0, 64)},
		"hillside": {"tavern": Vector3(-22, 0, 12), "store": Vector3(22, 0, 12), "yard": Vector3(48, 0, 2), "gov": Vector3(0, 0, 64)},
		"boulevard": {"tavern": Vector3(-18, 0, 50), "store": Vector3(18, 0, 50), "yard": Vector3(-52, 0, 6), "gov": Vector3(0, 0, 72)},
		"canal": {"tavern": Vector3(-56, 0, 30), "store": Vector3(56, 0, 30), "yard": Vector3(50, 0, 6), "gov": Vector3(0, 0, 60)},
		"scatter": {"tavern": Vector3(-16, 0, 10), "store": Vector3(20, 0, 16), "yard": Vector3(46, 0, 4), "gov": Vector3(-10, 0, 64)},
	}
	var sp: Dictionary = SPECIAL_SPOTS.get(layout, SPECIAL_SPOTS["rows"])
	_special_building(sp["tavern"], Vector3(12, 7, 9), Color("b0765a"), "선술집",
		"선술집 - 선원 고용, 퀘스트", "tavern", 0)
	_special_building(sp["store"], Vector3(12, 7, 9), Color("e6d3a8"), "상점",
		"상점 - 교역품", "store", 1)
	_special_building(sp["yard"], Vector3(14, 6, 12), Color("c9b8a0"), "조선소",
		"조선소 - 선박, 탄약, 수리", "shipyard", 2)
	var gpos: Vector3 = sp["gov"]
	_special_building(gpos, Vector3(18, 9, 12), Color("f2ede0"), "총독",
		"총독부 - 퀘스트와 알현", "governor", 0)
	for cx in [-6.0, -2.0, 2.0, 6.0]:
		_mesh_cyl(0.45, 0.45, 7.0, gpos + Vector3(cx, 3.5, -6.8), Color("f5f1e6"))

	# Then the houses fill whatever the layout leaves free.
	var spots: Array = []
	match layout:
		"plaza":
			for x in [-28.0, -14.0, 14.0, 28.0]:
				spots.append({"pos": Vector3(x, 0, 16), "size": Vector3(7, 5, 6)})
				spots.append({"pos": Vector3(x, 0, 46), "size": Vector3(7, 5.5, 6)})
			for z in [24.0, 38.0]:
				spots.append({"pos": Vector3(-38, 0, z), "size": Vector3(6, 5, 6)})
				spots.append({"pos": Vector3(38, 0, z), "size": Vector3(6, 5, 6)})
		"terraces":
			for i in 5:
				spots.append({"pos": Vector3(-44 + i * 15.5, 0, 25 + _rng.randf_range(-1, 1)), "size": Vector3(7, 5, 6)})
			for i in 4:
				spots.append({"pos": Vector3(-28 + i * 16.5, 0, 41), "size": Vector3(7.5, 5.5, 6.5)})
			for i in 3:
				spots.append({"pos": Vector3(-12 + i * 17.0, 0, 57), "size": Vector3(8, 6, 7)})
		"hillside":
			for i in 9:
				var ang := deg_to_rad(-62.0 + i * 15.5)
				var r := 34.0 + (i % 2) * 12.0
				var p := Vector3(sin(ang) * r * 1.35, 0, 32.0 + cos(ang) * r * 0.62)
				if absf(p.x) < 10.0:
					continue
				spots.append({"pos": p, "size": Vector3(7, 5, 6)})
		"boulevard":
			for i in 10:
				var x := -58.0 + i * 13.0
				if absf(x) < 9.0:
					continue
				spots.append({"pos": Vector3(x, 0, 21), "size": Vector3(7, 5.5, 6)})
				spots.append({"pos": Vector3(x + 3.0, 0, 39), "size": Vector3(7, 5, 6)})
		"canal":
			for i in 9:
				var x := -48.0 + i * 12.0
				spots.append({"pos": Vector3(x, 0, 13), "size": Vector3(5.5, 7, 5.5)})
				spots.append({"pos": Vector3(x + 4.0, 0, 47), "size": Vector3(5.5, 6.5, 5.5)})
		"scatter":
			for i in 14:
				spots.append({
					"pos": Vector3(_rng.randf_range(-55, 55), 0, _rng.randf_range(14, 60)),
					"size": Vector3(_rng.randf_range(5.5, 8.0), _rng.randf_range(4.0, 5.5), _rng.randf_range(5.0, 7.0)),
				})
		_:
			for i in 9:
				var x := -52.0 + i * 13.0 + _rng.randf_range(-2, 2)
				if absf(x) < 9.0:
					continue
				spots.append({"pos": Vector3(x, 0, 26 + _rng.randf_range(-2, 2)), "size": Vector3(7, 5, 6)})
			for i in 7:
				var x2 := -45.0 + i * 15.0 + _rng.randf_range(-2, 2)
				if absf(x2) < 9.0:
					continue
				spots.append({"pos": Vector3(x2, 0, 44 + _rng.randf_range(-2, 2)), "size": Vector3(8, 5.5, 7)})

	for s in spots:
		if _area_free(s["pos"], s["size"]):
			_house(s["pos"], s["size"])


## A colonial house: timber-framed walls, windows with shutters, a door,
## a roof with an overhang, sometimes a chimney. Registers a collider and
## builds an enterable interior behind its door.
func _house(pos: Vector3, size: Vector3, wall_c: Color = Color.TRANSPARENT, roof_c: Color = Color.TRANSPARENT,
		kind: String = "house", title: String = "집", ui_tab: int = -1) -> void:
	var wall: Color = wall_c if wall_c.a > 0.0 else WALL_COLORS[_rng.randi_range(0, WALL_COLORS.size() - 1)]
	var roof: Color = roof_c if roof_c.a > 0.0 else ROOF_COLORS[_rng.randi_range(0, ROOF_COLORS.size() - 1)]
	if _house_model(pos, size, kind):
		_finish_house(pos, size, kind, title, ui_tab)
		return

	var body := _mesh_box(size, pos + Vector3(0, size.y / 2.0, 0), wall)
	body.material_override = PBR.mat("painted_plaster_wall", 3.0, wall)

	# Timber frame: corner posts + a horizontal beam.
	var timber := PBR.mat("dark_wooden_planks", 1.5)
	for corner in [Vector3(-1, 0, -1), Vector3(1, 0, -1), Vector3(-1, 0, 1), Vector3(1, 0, 1)]:
		_mesh_box(Vector3(0.28, size.y, 0.28),
			pos + Vector3(corner.x * size.x / 2.0, size.y / 2.0, corner.z * size.z / 2.0), TIMBER).material_override = timber
	_mesh_box(Vector3(size.x + 0.1, 0.22, 0.1), pos + Vector3(0, size.y * 0.55, -size.z / 2.0 - 0.06), TIMBER).material_override = timber

	# Roof with overhang + sometimes a chimney.
	var roof_mesh := MeshInstance3D.new()
	var pm := PrismMesh.new()
	pm.size = Vector3(size.x + 1.4, size.y * 0.55, size.z + 1.4)
	roof_mesh.mesh = pm
	roof_mesh.position = pos + Vector3(0, size.y + size.y * 0.275, 0)
	roof_mesh.material_override = PBR.mat("clay_roof_tiles_02", 2.0, roof.lerp(Color.WHITE, 0.45))
	add_child(roof_mesh)
	if _rng.randf() < 0.5:
		_mesh_box(Vector3(0.8, size.y * 0.8, 0.8), pos + Vector3(size.x * 0.25, size.y + size.y * 0.5, 0), Color("6e6257")).material_override = PBR.mat("plaster_stone_wall_01", 1.5)

	# Door with a frame and a step.
	_mesh_box(Vector3(1.5, 2.6, 0.12), pos + Vector3(0, 1.3, -size.z / 2.0 - 0.10), TIMBER).material_override = timber
	_mesh_box(Vector3(1.15, 2.3, 0.16), pos + Vector3(0, 1.15, -size.z / 2.0 - 0.14), Color("5d4024")).material_override = PBR.mat("brown_planks_05", 1.2)
	_mesh_box(Vector3(2.0, 0.24, 1.0), pos + Vector3(0, 0.12, -size.z / 2.0 - 0.5), Color("8d8577")).material_override = PBR.mat("seaworn_stone_tiles", 1.5)

	# Two windows with white frames and colored shutters.
	var shutter: Color = [Color("3f6b58"), Color("35405c"), Color("8d3a2e")][_rng.randi_range(0, 2)]
	for wx in [-size.x * 0.28, size.x * 0.28]:
		_mesh_box(Vector3(1.3, 1.5, 0.10), pos + Vector3(wx, size.y * 0.55, -size.z / 2.0 - 0.08), Color("f5f1e6"))
		_mesh_box(Vector3(1.0, 1.2, 0.14), pos + Vector3(wx, size.y * 0.55, -size.z / 2.0 - 0.10), Color("20303c"))
		for sx in [-0.85, 0.85]:
			_mesh_box(Vector3(0.45, 1.3, 0.08), pos + Vector3(wx + sx, size.y * 0.55, -size.z / 2.0 - 0.09), shutter)

	_finish_house(pos, size, kind, title, ui_tab)


## Collider plus the furnished interior behind the front door.
func _finish_house(pos: Vector3, size: Vector3, kind: String, title: String, ui_tab: int) -> void:
	_colliders.append(Rect2(pos.x - size.x / 2.0 - 0.6, pos.z - size.z / 2.0 - 0.6, size.x + 1.2, size.z + 1.2))

	# Every building is enterable: the door leads to a furnished room.
	var room := _build_interior(kind, title, ui_tab)
	_interactables.append({
		"pos": pos + Vector3(0, 1.0, -size.z / 2.0 - 1.2),
		"label": "%s 들어가기" % title,
		"action": func(): _enter_interior(room),
	})


## A modelled colonial house (Higgsfield → Hunyuan3D, see
## tools/blender/import_houses.py) fitted to the lot, door to the street.
## Returns false when the models are missing, so the box house is built.
func _house_model(pos: Vector3, size: Vector3, kind: String) -> bool:
	if not ResourceLoader.exists("res://assets/houses/houses.json"):
		return false
	if _house_sizes.is_empty():
		_house_sizes = JSON.parse_string(FileAccess.get_file_as_string("res://assets/houses/houses.json"))
	var id := "tavern" if kind == "tavern" else ("house_white" if kind in ["governor", "store"] or _rng.randf() < 0.5 else "house_yellow")
	if not _house_sizes.has(id):
		id = "house_white"
	var dims: Dictionary = _house_sizes[id]
	var k := minf(size.x / float(dims["x"]), size.z / float(dims["z"])) * 1.08
	var model: Node3D = load("res://assets/houses/%s.gltf" % id).instantiate()
	model.position = pos
	model.scale = Vector3.ONE * k
	add_child(model)
	return true


func _special_building(pos: Vector3, size: Vector3, wall: Color, sign_text: String,
		hint: String, kind: String, ui_tab: int) -> void:
	_house(pos, size, wall, Color.TRANSPARENT, kind, "%s" % sign_text.to_lower(), ui_tab)
	var sign := Label3D.new()
	sign.font = preload("res://assets/fonts/NanumGothic-Regular.ttf")
	sign.text = sign_text
	sign.font_size = 220
	sign.pixel_size = 0.01
	sign.modulate = Color("ffe9b0")
	sign.outline_size = 24
	sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sign.position = pos + Vector3(0, size.y * 1.75 + 1.4, 0)
	add_child(sign)
	# A hanging wooden signboard by the door too.
	_mesh_box(Vector3(1.6, 1.0, 0.1), pos + Vector3(size.x * 0.4, 3.2, -size.z / 2.0 - 0.4), Color("5d4024"))


## Street furniture: lamp posts, a well, a market stall.
func _build_props() -> void:
	for z in [8.0, 22.0, 36.0, 50.0]:
		for x in [-7.5, 7.5]:
			_mesh_cyl(0.09, 0.12, 3.4, Vector3(x, 1.7, z), TIMBER).material_override = PBR.mat("dark_wooden_planks", 1.0)
			_prop("wooden_lantern_01", Vector3(x, 3.4, z), 0.0, 1.6)
			var lamp := MeshInstance3D.new()
			var lm := SphereMesh.new()
			lm.radius = 0.11
			lm.height = 0.22
			lamp.mesh = lm
			lamp.position = Vector3(x, 3.75, z)
			lamp.material_override = _mat(Color(1.0, 0.8, 0.45), true)
			add_child(lamp)

	# Town well on the square.
	_mesh_cyl(1.3, 1.4, 1.0, Vector3(-4, 0.5, 16), Color("8d8577")).material_override = PBR.mat("plaster_stone_wall_01", 1.5)
	_mesh_cyl(0.09, 0.09, 2.2, Vector3(-5.1, 1.9, 16), TIMBER)
	_mesh_cyl(0.09, 0.09, 2.2, Vector3(-2.9, 1.9, 16), TIMBER)
	var well_roof := MeshInstance3D.new()
	var wrm := PrismMesh.new()
	wrm.size = Vector3(3.2, 1.0, 2.4)
	well_roof.mesh = wrm
	well_roof.position = Vector3(-4, 3.3, 16)
	well_roof.material_override = PBR.mat("clay_roof_tiles_02", 1.5)
	add_child(well_roof)
	_colliders.append(Rect2(-5.6, 14.4, 3.2, 3.2))

	# Market stall near the store: striped awning over crates.
	for px in [21.0, 25.0]:
		for pz in [17.0, 20.0]:
			_mesh_cyl(0.08, 0.08, 2.6, Vector3(px, 1.3, pz), TIMBER)
	var awning := MeshInstance3D.new()
	var am := PrismMesh.new()
	am.size = Vector3(5.4, 0.9, 4.2)
	awning.mesh = am
	awning.position = Vector3(23, 3.0, 18.5)
	awning.material_override = _mat(Color("a8453a"))
	add_child(awning)
	_mesh_box(Vector3(3.6, 1.0, 2.4), Vector3(23, 0.5, 18.5), Color("8a6a3f"))
	for i in 4:
		_mesh_box(Vector3(0.8, 0.5, 0.6),
			Vector3(21.8 + (i % 2) * 2.4, 1.25, 17.8 + int(i / 2.0) * 1.4),
			[Color("b0765a"), Color("6b7d4a"), Color("c9a24a"), Color("8d3a2e")][i])
	_colliders.append(Rect2(20.0, 16.0, 6.0, 5.0))


# --- Interiors ---

## Build a furnished room for a building and return its entry data.
## kind: "tavern" | "store" | "shipyard" | "governor" | "house"
func _build_interior(kind: String, title: String, ui_tab: int) -> Dictionary:
	var base := Vector3(300 + _interior_count * 50, -60, 0)
	_interior_count += 1
	var w := 13.0
	var d := 10.0
	var h := 4.2
	var wall_c := Color("d9cfb8")
	var floor_c := Color("6b5233")

	# Shell: floor, ceiling, four walls.
	_mesh_box(Vector3(w, 0.3, d), base + Vector3(0, -0.15, 0), floor_c)
	_mesh_box(Vector3(w, 0.3, d), base + Vector3(0, h, 0), Color("3a2d1c"))
	_mesh_box(Vector3(w, h, 0.3), base + Vector3(0, h / 2.0, -d / 2.0), wall_c)
	_mesh_box(Vector3(w, h, 0.3), base + Vector3(0, h / 2.0, d / 2.0), wall_c)
	_mesh_box(Vector3(0.3, h, d), base + Vector3(-w / 2.0, h / 2.0, 0), wall_c)
	_mesh_box(Vector3(0.3, h, d), base + Vector3(w / 2.0, h / 2.0, 0), wall_c)
	# Door mark on the front wall + glowing windows + warm light.
	_mesh_box(Vector3(1.3, 2.5, 0.1), base + Vector3(0, 1.25, d / 2.0 - 0.12), Color("3a2513"))
	for wx in [-w * 0.3, w * 0.3]:
		_mesh_box(Vector3(1.4, 1.2, 0.1), base + Vector3(wx, 2.3, -d / 2.0 + 0.12), Color(1.0, 0.87, 0.6), true)
	var light := OmniLight3D.new()
	light.position = base + Vector3(0, h - 0.8, 0)
	light.light_color = Color(1.0, 0.85, 0.62)
	light.light_energy = 1.6
	light.omni_range = 16.0
	add_child(light)

	_furnish(kind, base, w, d, ui_tab, title)

	var spawn := base + Vector3(0, 0.1, d / 2.0 - 1.6)
	_interactables.append({
		"pos": base + Vector3(0, 1.0, d / 2.0 - 0.8),
		"label": "%s 나가기" % title,
		"action": func(): _exit_interior(),
	})
	return {
		"spawn": spawn,
		"bounds": Rect2(base.x - w / 2.0 + 0.7, base.z - d / 2.0 + 0.7, w - 1.4, d - 1.4),
		"floor_y": base.y,
	}


func _furnish(kind: String, base: Vector3, w: float, d: float, ui_tab: int, title: String) -> void:
	match kind:
		"tavern":
			# Bar counter, kegs, tables with stools, a fireplace.
			_mesh_box(Vector3(0.9, 1.1, d * 0.55), base + Vector3(w / 2.0 - 1.3, 0.55, 0), Color("4a2e15"))
			for i in 3:
				_mesh_cyl(0.42, 0.46, 1.0, base + Vector3(w / 2.0 - 0.7, 0.5, -d * 0.28 + i * 1.4), Color("5d4024"))
			for tp in [Vector3(-2.5, 0, 1.2), Vector3(-3.2, 0, -2.2), Vector3(1.2, 0, -1.6)]:
				_table_with_stools(base + tp)
			_fireplace(base + Vector3(-w / 2.0 + 0.7, 0, -d * 0.2))
			_room_npc(base + Vector3(w / 2.0 - 2.4, 0, 0), Color("8d3a2e"),
				"주모 - 선원, 퀘스트, 소문", ui_tab)
		"store":
			for sx in [-w * 0.28, w * 0.05]:
				_shelf(base + Vector3(sx, 0, -d / 2.0 + 0.9))
			_mesh_box(Vector3(2.6, 1.05, 0.8), base + Vector3(w * 0.28, 0.52, 0.5), Color("4a2e15"))
			for i in 5:
				_mesh_box(Vector3(0.7, 0.7, 0.7),
					base + Vector3(-w * 0.3 + i * 0.9, 0.35, d * 0.28),
					[Color("b0765a"), Color("6b7d4a"), Color("c9a24a"), Color("8d3a2e"), Color("35405c")][i])
			_room_npc(base + Vector3(w * 0.28, 0, -0.6), Color("6b7d4a"),
				"상인 - 교역품 매매", ui_tab)
		"shipyard":
			for i in 3:
				var log := _mesh_cyl(0.28, 0.28, 5.0, base + Vector3(-w * 0.25, 0.3 + i * 0.5, -d * 0.3 + i * 0.1), Color("6b4a2b"))
				log.rotation_degrees = Vector3(0, 0, 90)
			_mesh_box(Vector3(3.2, 0.9, 1.2), base + Vector3(w * 0.22, 0.45, -d * 0.25), Color("4a2e15"))
			_mesh_box(Vector3(0.5, 0.5, 2.6), base + Vector3(w * 0.22, 1.15, -d * 0.25), Color("8a6a3f"))
			for i in 4:
				_mesh_cyl(0.3, 0.34, 0.8, base + Vector3(-w * 0.15 + i * 1.1, 0.4, d * 0.28), Color("5d4024"))
			_room_npc(base + Vector3(w * 0.22, 0, 0.8), Color("35405c"),
				"조선공 - 선박, 탄약, 수리", ui_tab)
		"governor":
			_mesh_box(Vector3(w * 0.6, 0.06, d * 0.5), base + Vector3(0, 0.03, 0), Color("7a2c2c"))
			_mesh_box(Vector3(2.8, 0.9, 1.3), base + Vector3(0, 0.45, -d * 0.22), Color("4a2e15"))
			_mesh_box(Vector3(0.7, 1.3, 0.7), base + Vector3(0, 0.65, -d * 0.36), Color("6e3a28"))
			for cx in [-w * 0.3, w * 0.3]:
				_mesh_cyl(0.35, 0.4, 4.0, base + Vector3(cx, 2.0, -d * 0.1), Color("f0ece0"))
			_shelf(base + Vector3(w * 0.32, 0, -d / 2.0 + 0.9))
			_room_npc(base + Vector3(0, 0, -d * 0.16), Color("35405c"),
				"총독부 - 퀘스트와 알현", ui_tab)
		_:
			# A commoner's home: bed, table, chest, sometimes someone in.
			_mesh_box(Vector3(2.2, 0.5, 1.2), base + Vector3(-w * 0.28, 0.25, -d * 0.3), Color("6e3a28"))
			_mesh_box(Vector3(0.6, 0.18, 1.0), base + Vector3(-w * 0.36, 0.6, -d * 0.3), Color("e8e2d0"))
			_table_with_stools(base + Vector3(w * 0.15, 0, 0.4))
			_mesh_box(Vector3(1.1, 0.7, 0.7), base + Vector3(w * 0.3, 0.35, -d * 0.32), Color("5d4024"))
			_fireplace(base + Vector3(-w / 2.0 + 0.7, 0, d * 0.15))
			if _rng.randf() < 0.6:
				_room_npc(base + Vector3(w * 0.1, 0, -d * 0.15),
					NPC_CLOTHES[_rng.randi_range(0, NPC_CLOTHES.size() - 1)], "", -1)


func _table_with_stools(pos: Vector3) -> void:
	_mesh_cyl(0.8, 0.8, 0.08, pos + Vector3(0, 0.78, 0), Color("8a6a3f"))
	_mesh_cyl(0.09, 0.11, 0.76, pos + Vector3(0, 0.38, 0), Color("4a2e15"))
	for i in 3:
		var ang := TAU * i / 3.0 + 0.5
		_mesh_cyl(0.26, 0.26, 0.45, pos + Vector3(cos(ang) * 1.15, 0.22, sin(ang) * 1.15), Color("5d4024"))


func _shelf(pos: Vector3) -> void:
	_mesh_box(Vector3(3.0, 2.4, 0.5), pos + Vector3(0, 1.2, 0), Color("4a2e15"))
	for row in 3:
		for i in 4:
			_mesh_box(Vector3(0.45, 0.4, 0.4),
				pos + Vector3(-1.1 + i * 0.75, 0.55 + row * 0.75, -0.1),
				NPC_CLOTHES[(row * 4 + i) % NPC_CLOTHES.size()])


func _fireplace(pos: Vector3) -> void:
	_mesh_box(Vector3(1.6, 2.2, 0.9), pos + Vector3(0, 1.1, 0), Color("6e6257"))
	_mesh_box(Vector3(0.9, 0.8, 0.5), pos + Vector3(0, 0.5, 0.25), Color(1.0, 0.55, 0.15), true)


## A static NPC standing in a room; optional Talk interaction opens a UI tab.
func _room_npc(pos: Vector3, cloth: Color, talk_label: String, ui_tab: int) -> void:
	var person := Person.build(cloth, Color("d9a97a"), false, 0 if talk_label == "" else 1)
	var npc: Node3D = person["root"]
	npc.position = pos
	npc.rotation.y = PI  # face the door
	add_child(npc)
	# Arms resting slightly outward.
	person["l_arm"].rotation.z = 0.18
	person["r_arm"].rotation.z = -0.18
	if talk_label != "":
		_interactables.append({
			"pos": pos + Vector3(0, 1.0, 0),
			"label": talk_label,
			"action": func(): Game.goto_port_ui(ui_tab),
		})


func _enter_interior(room: Dictionary) -> void:
	_return_pos = player.position
	_inside = true
	_room_bounds = room["bounds"]
	_room_floor_y = room["floor_y"]
	player.position = room["spawn"]
	camera.position = player.position + Vector3(0, 3, 6)


func _exit_interior() -> void:
	_inside = false
	player.position = _return_pos
	camera.position = player.position + Vector3(0, 4, 10)


# --- Harbor sailing ---

func _board_ship() -> void:
	_sailing = true
	_ship_heading = wrapf(-ANCHOR_ROT_Y, 0.0, 360.0)
	Game.state.ship.sail_setting = 0.5
	Game.state.ship.heading = _ship_heading
	# Put the captain on the quarterdeck; he now moves with the ship.
	player.get_parent().remove_child(player)
	_ship_node.add_child(player)
	player.position = Vector3(0, _ship_node._deck_y(0.8) + 0.6, _ship_len * 0.30)
	player.rotation.y = 0.0
	cam_dist = 46.0
	cam_pitch = 16.0
	_hint.text = ""


func _dock_ship() -> void:
	_sailing = false
	Game.state.ship.sail_setting = 0.0
	_ship_node.set_sail_amount(0.06)
	_ship_node.position = ANCHOR_POS
	_ship_node.rotation_degrees = Vector3(0, ANCHOR_ROT_Y, 0)
	# The captain steps back onto the quay.
	_ship_node.remove_child(player)
	add_child(player)
	player.position = Vector3(14, 0.95, 2)
	cam_dist = 15.0
	Game.save_game()


func _sail_tick(delta: float) -> void:
	var ship = Game.state.ship
	var wind: Dictionary = Game.state.wind
	var nav: int = Game.state.character.skill("navigation")

	if Input.is_action_just_pressed("sails_up"):
		ship.sail_setting = clampf(ship.sail_setting + 0.5, 0.0, 1.0)
	if Input.is_action_just_pressed("sails_down"):
		ship.sail_setting = clampf(ship.sail_setting - 0.5, 0.0, 1.0)

	ship.heading = _ship_heading
	var speed: float = Sailing.ship_speed(ship, wind["from"], wind["strength"], nav)
	var turn: float = Sailing.turn_speed(ship, speed, nav)
	if Input.is_action_pressed("turn_left"):
		_ship_heading = wrapf(_ship_heading - turn * delta, 0.0, 360.0)
	if Input.is_action_pressed("turn_right"):
		_ship_heading = wrapf(_ship_heading + turn * delta, 0.0, 360.0)

	var fwd := Vector3(sin(deg_to_rad(_ship_heading)), 0, -cos(deg_to_rad(_ship_heading)))
	_ship_node.position += fwd * speed * SAIL_SPEED_SCALE * delta
	_ship_node.rotation.y = -deg_to_rad(_ship_heading)
	# Keep the ship inside the bay (the quay wall and map edges).
	_ship_node.position.x = clampf(_ship_node.position.x, -400.0, 400.0)
	_ship_node.position.z = clampf(_ship_node.position.z, -700.0, -16.0)
	_ship_node.set_sail_amount(maxf(ship.sail_setting, 0.06))
	_ship_node.set_speed_visual(speed)
	_ship_node.bob(_time, 0.7)
	_ship_node.position.y += -0.8

	# Camera orbits the ship.
	var yr := deg_to_rad(cam_yaw)
	var pr := deg_to_rad(cam_pitch)
	var off := Vector3(sin(yr) * cos(pr), sin(pr), cos(yr) * cos(pr)) * maxf(cam_dist, 25.0)
	camera.position = camera.position.lerp(_ship_node.position + Vector3(0, 8, 0) + off, 6.0 * delta)
	camera.look_at(_ship_node.position + Vector3(0, 6, 0))

	# Contextual hints: dock near the quay, or sail out to the open sea.
	# Enter always leaves for the world map, from anywhere in the bay.
	var near_dock: bool = _ship_node.position.distance_to(ANCHOR_POS) < 40.0
	var far_out: bool = _ship_node.position.z < -260.0
	if near_dock:
		_hint.text = "[E]  부두에 정박   |   [Enter]  먼바다 - 세계 지도"
		if Input.is_action_just_pressed("interact"):
			_dock_ship()
	elif far_out:
		_hint.text = "[E / Enter]  먼바다로 출항"
		if Input.is_action_just_pressed("interact"):
			Game.goto_open_sea_from_port()
	else:
		_hint.text = "W/S - 돛, A/D - 키 | %.1f노트 | [Enter]  먼바다 - 세계 지도" % speed
	if Input.is_key_pressed(KEY_ENTER) or Input.is_key_pressed(KEY_KP_ENTER):
		Game.goto_open_sea_from_port()


# --- Townsfolk ---

## Wandering NPCs: {root, l_leg, r_leg (may be null for skirts), target, speed, phase}
var _npcs: Array = []

const NPC_CLOTHES := [Color("8d3a2e"), Color("6b7d4a"), Color("b0765a"), Color("35405c"), Color("c9a24a"), Color("7d5a7a")]


func _build_npcs() -> void:
	for i in 9:
		var cloth: Color = NPC_CLOTHES[i % NPC_CLOTHES.size()]
		var skin := Color("d9a97a").lerp(Color("8d6a4a"), _rng.randf() * 0.6)
		var skirted := _rng.randf() < 0.45
		var person := Person.build(cloth, skin, skirted, _rng.randi_range(0, 2))
		var npc: Node3D = person["root"]
		add_child(npc)
		npc.position = _npc_spot()
		_npcs.append({
			"root": npc, "l_leg": person["l_leg"], "r_leg": person["r_leg"],
			"l_arm": person["l_arm"], "r_arm": person["r_arm"],
			"target": _npc_spot(), "speed": _rng.randf_range(1.6, 3.0), "phase": _rng.randf() * TAU,
		})


## A random walkable point on the streets, outside building footprints.
func _npc_spot() -> Vector3:
	for attempt in 12:
		var p := Vector3(_rng.randf_range(-55, 55), 0.08, _rng.randf_range(2, 52))
		var p2 := Vector2(p.x, p.z)
		var blocked := false
		for rect: Rect2 in _colliders:
			if rect.grow(0.5).has_point(p2):
				blocked = true
				break
		if not blocked:
			return p
	return Vector3(0, 0.08, 10)


func _process_npcs(delta: float) -> void:
	for n in _npcs:
		var root: Node3D = n["root"]
		var to_target: Vector3 = n["target"] - root.position
		to_target.y = 0.0
		if to_target.length() < 0.5:
			n["target"] = _npc_spot()
			continue
		var step: Vector3 = to_target.normalized() * n["speed"] * delta
		root.position += step
		root.rotation.y = atan2(-step.x, -step.z)
		n["phase"] += delta * 6.0 * n["speed"]
		var swing: float = sin(n["phase"]) * 0.5
		if n["l_leg"] != null:
			n["l_leg"].rotation.x = swing
			n["r_leg"].rotation.x = -swing
		else:
			root.position.y = 0.08 + absf(sin(n["phase"])) * 0.05
		n["l_arm"].rotation.x = -swing * 0.6
		n["r_arm"].rotation.x = swing * 0.6


# --- Player ---

func _build_player() -> void:
	# The captain: a rigged character model, limbs driven through pivots.
	var p := Person.build(Color("2c3a5c"), Person.SKIN_DEFAULT, false, 1, false, "captain")
	player = p["root"]
	add_child(player)
	player.position = Vector3(0, 0.95, 2)
	for limb in ["l_leg", "r_leg", "l_arm", "r_arm"]:
		_limbs[limb] = p[limb]


var _hud: CanvasLayer
var _status: Label


func _build_hud() -> void:
	_hud = CanvasLayer.new()
	add_child(_hud)

	var panel := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.04, 0.09, 0.14, 0.8)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 5
	style.content_margin_bottom = 5
	panel.add_theme_stylebox_override("panel", style)
	panel.position = Vector2(12, 10)
	_hud.add_child(panel)

	_status = Label.new()
	_status.add_theme_color_override("font_color", Color("e8c872"))
	_status.add_theme_font_size_override("font_size", 15)
	var isl := _island()
	_status.text = "%s (%s) | %d일차 | %d골드 | WASD - 걷기, E - 들어가기, 우클릭 - 카메라, Tab - 항구 메뉴" % [
		isl["name"], World.NATIONS[isl["nation"]]["name"], Game.state.day, Game.state.character.gold]
	panel.add_child(_status)

	_hint = Label.new()
	_hint.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_hint.position = Vector2(440, 620)
	_hint.add_theme_font_size_override("font_size", 20)
	_hint.add_theme_color_override("font_color", Color("ffffff"))
	_hud.add_child(_hint)


# --- Input & movement ---

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_RIGHT:
			_orbiting = event.pressed
		elif event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
			cam_dist = clampf(cam_dist * 0.9, 6.0, 40.0)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
			cam_dist = clampf(cam_dist * 1.1, 6.0, 40.0)
	elif event is InputEventMouseMotion and _orbiting:
		cam_yaw = wrapf(cam_yaw - event.relative.x * 0.35, 0.0, 360.0)
		cam_pitch = clampf(cam_pitch + event.relative.y * 0.25, 4.0, 60.0)
	elif event is InputEventKey and event.pressed and event.physical_keycode == KEY_TAB:
		Game.goto_port_ui()


func _physics_process(delta: float) -> void:
	_time += delta
	DayCycle.apply(_sun, _env_res, Game.time_of_day, _look)
	if _sailing:
		_sail_tick(delta)
		_process_npcs(delta)
		return
	# Movement relative to the camera yaw.
	var dir := Vector2.ZERO
	if Input.is_action_pressed("sails_up"):
		dir.y += 1.0
	if Input.is_action_pressed("sails_down"):
		dir.y -= 1.0
	if Input.is_action_pressed("turn_left"):
		dir.x -= 1.0
	if Input.is_action_pressed("turn_right"):
		dir.x += 1.0
	_moving = dir != Vector2.ZERO
	if _moving:
		dir = dir.normalized()
		var yr := deg_to_rad(cam_yaw)
		var fwd := Vector3(-sin(yr), 0, -cos(yr))
		var right := Vector3(-fwd.z, 0, fwd.x)
		var motion := (fwd * dir.y + right * dir.x) * WALK_SPEED * delta
		player.position += motion
		if _inside:
			player.position.x = clampf(player.position.x, _room_bounds.position.x, _room_bounds.end.x)
			player.position.z = clampf(player.position.z, _room_bounds.position.y, _room_bounds.end.y)
		else:
			player.position.x = clampf(player.position.x, -70.0, 70.0)
			player.position.z = clampf(player.position.z, -9.0, 80.0)
			_resolve_collisions()
		player.rotation.y = atan2(-motion.x, -motion.z)

	# Snap to the ground: room floor inside, quay top or grass outside.
	var target_y: float
	if _inside:
		target_y = _room_floor_y + 0.08
	else:
		target_y = 0.95 if player.position.z < 1.5 else 0.08
	player.position.y = lerpf(player.position.y, target_y, 12.0 * delta)

	_animate_walk(delta)
	_process_npcs(delta)

	# Ship bobbing at anchor.
	if _ship_node != null:
		_ship_node.bob(_time, 0.7)
		_ship_node.position.y += -0.8

	# Orbit camera around the player (pulled in close indoors).
	var yr2 := deg_to_rad(cam_yaw)
	var pr := deg_to_rad(cam_pitch)
	var eff_dist := minf(cam_dist, 6.5) if _inside else cam_dist
	var off := Vector3(sin(yr2) * cos(pr), sin(pr), cos(yr2) * cos(pr)) * eff_dist
	camera.position = camera.position.lerp(player.position + Vector3(0, 1.6, 0) + off, 10.0 * delta)
	if _inside:
		# Keep the camera inside the room walls.
		camera.position.x = clampf(camera.position.x, _room_bounds.position.x + 0.3, _room_bounds.end.x - 0.3)
		camera.position.z = clampf(camera.position.z, _room_bounds.position.y + 0.3, _room_bounds.end.y - 0.3)
		camera.position.y = clampf(camera.position.y, _room_floor_y + 1.2, _room_floor_y + 3.6)
	camera.look_at(player.position + Vector3(0, 1.8, 0))

	# Nearest interactable within range.
	var best = null
	var best_d := 6.0
	for it in _interactables:
		var d: float = player.position.distance_to(it["pos"])
		if d < best_d:
			best_d = d
			best = it
	if best != null:
		_hint.text = "[E]  %s" % best["label"]
		if Input.is_action_just_pressed("interact"):
			best["action"].call()
	else:
		_hint.text = ""


## Push the player out of building footprints (simple AABB resolution).
func _resolve_collisions() -> void:
	var p := Vector2(player.position.x, player.position.z)
	for rect: Rect2 in _colliders:
		if not rect.has_point(p):
			continue
		var left := p.x - rect.position.x
		var right := rect.position.x + rect.size.x - p.x
		var near := p.y - rect.position.y
		var far := rect.position.y + rect.size.y - p.y
		var m := minf(minf(left, right), minf(near, far))
		if m == left:
			p.x = rect.position.x
		elif m == right:
			p.x = rect.position.x + rect.size.x
		elif m == near:
			p.y = rect.position.y
		else:
			p.y = rect.position.y + rect.size.y
	player.position.x = p.x
	player.position.z = p.y


## Swing arms and legs while walking, settle when idle.
func _animate_walk(delta: float) -> void:
	if _moving:
		_walk_phase += delta * 9.0
	var target := sin(_walk_phase) * 0.55 if _moving else 0.0
	for pair in [["l_leg", 1.0], ["r_leg", -1.0], ["l_arm", -0.6], ["r_arm", 0.6]]:
		var pivot: Node3D = _limbs[pair[0]]
		pivot.rotation.x = lerpf(pivot.rotation.x, target * pair[1], 14.0 * delta)
